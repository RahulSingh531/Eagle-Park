const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const DATA_FILE = path.join(__dirname, 'tasks.json');

// load tasks or initialize
function loadTasks(){
  try {
    const raw = fs.readFileSync(DATA_FILE);
    return JSON.parse(raw);
  } catch(e){
    return [];
  }
}
function saveTasks(tasks){
  fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2));
}

// simple endpoints
app.get('/api/tasks', (req, res) => {
  const tasks = loadTasks();
  res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
  const tasks = loadTasks();
  const t = req.body;
  const newTask = {
    id: uuidv4(),
    task: t.task || 'New Task',
    assignedTo: t.assignedTo || '',
    dateAdded: t.dateAdded || new Date().toISOString().slice(0,10),
    difficulty: t.difficulty || 'Medium',
    hours: t.hours || 1,
    status: t.status || 'Todo',
    notes: t.notes || ''
  };
  tasks.push(newTask);
  saveTasks(tasks);
  res.status(201).json(newTask);
});

app.put('/api/tasks/:id', (req, res) => {
  const tasks = loadTasks();
  const id = req.params.id;
  const idx = tasks.findIndex(x => x.id === id);
  if(idx === -1) return res.status(404).send({error:'Not found'});
  const updated = {...tasks[idx], ...req.body};
  tasks[idx] = updated;
  saveTasks(tasks);
  res.json(updated);
});

app.delete('/api/tasks/:id', (req, res) => {
  let tasks = loadTasks();
  const id = req.params.id;
  const before = tasks.length;
  tasks = tasks.filter(t => t.id !== id);
  if(tasks.length === before) return res.status(404).send({error:'Not found'});
  saveTasks(tasks);
  res.status(204).send();
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('EaglePark backend listening on', PORT));
