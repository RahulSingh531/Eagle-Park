import React from 'react';
import axios from 'axios';

export default function TaskList({tasks, refresh}){
  async function toggleDone(task){
    const updated = {...task, status: task.status === 'Done' ? 'Todo' : 'Done'};
    await axios.put(`http://localhost:4000/api/tasks/${task.id}`, updated);
    refresh();
  }
  return (
    <div>
      <table style={{width:'100%',borderCollapse:'collapse'}}>
        <thead>
          <tr>
            <th style={{textAlign:'left',padding:8}}>Task</th>
            <th style={{textAlign:'left',padding:8}}>Assigned To</th>
            <th style={{padding:8}}>Difficulty</th>
            <th style={{padding:8}}>Hours</th>
            <th style={{padding:8}}>Status</th>
            <th style={{padding:8}}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map(t=>(
            <tr key={t.id} style={{borderTop:'1px solid #ddd'}}>
              <td style={{padding:8}}>{t.task}</td>
              <td style={{padding:8}}>{t.assignedTo}</td>
              <td style={{padding:8,textAlign:'center'}}>{t.difficulty}</td>
              <td style={{padding:8,textAlign:'center'}}>{t.hours}</td>
              <td style={{padding:8,textAlign:'center'}}>{t.status}</td>
              <td style={{padding:8,textAlign:'center'}}><button onClick={()=>toggleDone(t)}>Toggle Done</button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
