import React, { useEffect, useState } from 'react';
import axios from 'axios';
import TaskList from './TaskList';

export default function App(){
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{ fetchTasks(); }, []);

  async function fetchTasks(){
    try {
      const res = await axios.get('http://localhost:4000/api/tasks');
      setTasks(res.data);
    } catch(e){
      console.error(e);
      alert('Could not load tasks. Make sure backend is running on port 4000.');
    } finally { setLoading(false); }
  }

  return (
    <div style={{padding:20,fontFamily:'Arial, sans-serif',maxWidth:900,margin:'0 auto'}}>
      <h1>EaglePark App — Tasks</h1>
      {loading ? <p>Loading...</p> : <TaskList tasks={tasks} refresh={fetchTasks} />}
    </div>
  );
}
